<?php

namespace Drupal\authorization;

/**
 * Exception for when the entire profile should be skipped.
 */
class AuthorizationSkipAuthorization extends \Exception {

}
